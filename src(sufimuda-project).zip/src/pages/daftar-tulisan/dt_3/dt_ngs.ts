// Angular
import { Component } from '@angular/core';

// Ionic
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
    selector: 'dt_ngs',
    templateUrl: 'dt_ngs.html'
})

export class dt_ngsPage { 

	rootPage: any;
  	items: Array<{ title: string, page: any }>;



  constructor(public navCtrl: NavController, public navParams: NavParams) { 

     this.rootPage = 'ListsPage';
    this.items = [
      {
        title: '1.NASEHAT GURU KEPADA MURIDNYA',
        page : 'ngs_1Page'
      },
      {
        title: '2.Nasehat Guru Kepada Muridnya (2)',
        page : 'ngs_2Page'
      },
      {
        title: '3.SEUNTAI KATA HIKMAH PARA SYAIKHUL AKBAR GURU MURSYID THAREKAT NAQSYABANDI',
        page: 'ngs_3Page'
      },
      {
        title: '4.Kalian Jangan Hanya Sekedar Menjadi Aksesoris',
        page: 'ngs_4Page'
      },
      {
        title: '5.Ilmu ini (Hakikat) Turun dengan Kasih Sayang',
        page: 'ngs_5Page'
      }

    ];

    }
    itemTapped(event, item) {
    this.navCtrl.push(item.page);
  }
}
