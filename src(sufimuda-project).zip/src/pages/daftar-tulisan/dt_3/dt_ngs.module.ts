// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { dt_ngsPage } from './dt_ngs';

@NgModule({
    declarations: [dt_ngsPage],
    imports: [IonicPageModule.forChild(dt_ngsPage)],
    exports: [dt_ngsPage]
})
export class dt_ngsPageModule { }