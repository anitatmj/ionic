// Angular
import { Component } from '@angular/core';

// Ionic
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
    selector: 'dt_chas',
    templateUrl: 'dt_chas.html'
})

export class dt_chasPage { 

	rootPage: any;
  	items: Array<{ title: string, page: any }>;



  constructor(public navCtrl: NavController, public navParams: NavParams) { 

     this.rootPage = 'ListsPage';
    this.items = [
      {
        title: '1.Kisah Nenek Pemungut Daun',
        page : 'chas_1Page'
      },
      {
        title: '2.Humor Sufi : Takut Miskin di Akhirat',
        page : 'chas_2Page'
      },
      {
        title: '3.3 Hari Lagi Dunia Kiamat',
        page: 'chas_3Page'
      },
      {
        title: '4.Melihat Surga Amrozi',
        page: 'chas_4Page'
      },
      {
        title: '5.Prahara Kematian',
        page: 'chas_5Page'
      },
      {
        title: '6.Anekdot Seputar Emas',
        page: 'chas_6Page'
      },
      {
        title: '7.TERSESAT DI SURGA',
        page: 'chas_7Page'
      },
      {
        title: '8.Dialog Abu Yazid dan Pendeta',
        page: 'chas_8Page'
      },
      {
        title: '9.Keledai Membaca',
        page: 'chas_9Page'
      },
      {
        title: '10.Di Zawiyah Sebuah Mesjid',
        page: 'chas_10Page'
      },
      {
        title: '11.RAKSASA DAN SUFI',
        page: 'chas_11Page'
      },
      {
        title: '12.Membakar Rumah Allah',
        page: 'chas_12Page'
      },
      {
        title: '13.BAYAZID DAN ORANG YANG MEMIKIRKAN DIRI SENDIRI',
        page: 'chas_13Page'
      },
      {
        title: '14.NABI MUSA DAN PENGGEMBALA',
        page: 'chas_14Page'
      },
      {
        title: '15.AKIBAT TAMAK',
        page: 'chas_15Page'
      },
      {
        title: '16.ANJING, TONGKAT DAN SUFI',
        page: 'chas_16Page'
      },
      {
        title: '17.TIGA EKOR IKAN',
        page: 'chas_17Page'
      },
      {
        title: '18.SI TOLOL, SI BIJAK DAN SI KENDI',
        page: 'chas_18Page'
      },
      {
        title: '19.Apa Ada Kentut Islami?',
        page: 'chas_19Page'
      },
      {
        title: '20.GANJA dan SUFI',
        page: 'chas_20Page'
      },
      {
        title: '21.Tiga Orang Quraisy yang Terbaik Akhlaknya',
        page: 'chas_21Page'
      },
      {
        title: '22.MAKAN, TIDUR',
        page: 'chas_22Page'
      },
      {
        title: '23.SANG RAJA DAN ANAK MISKIN',
        page: 'chas_23Page'
      },
      {
        title: '24.TIGA ORANG DARWIS',
        page: 'chas_24Page'
      },
      {
        title: '25.Potensi Manusia Luar Biasa',
        page: 'chas_25Page'
      },
      {
        title: '26.Sebuah Cerita Bidah di Kampung Kami',
        page: 'chas_26Page'
      }


    ];

    }
    itemTapped(event, item) {
    this.navCtrl.push(item.page);
  }
}
