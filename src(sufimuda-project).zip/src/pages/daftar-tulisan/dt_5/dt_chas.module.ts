// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { dt_chasPage } from './dt_chas';

@NgModule({
    declarations: [dt_chasPage],
    imports: [IonicPageModule.forChild(dt_chasPage)],
    exports: [dt_chasPage]
})
export class dt_chasPageModule { }