// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { dt_trsPage } from './dt_trs';

@NgModule({
    declarations: [dt_trsPage],
    imports: [IonicPageModule.forChild(dt_trsPage)],
    exports: [dt_trsPage]
})
export class dt_trsPageModule { }