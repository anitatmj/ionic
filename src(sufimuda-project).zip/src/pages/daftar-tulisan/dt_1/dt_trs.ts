// Angular
import { Component } from '@angular/core';

// Ionic
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
    selector: 'dt_trs',
    templateUrl: 'dt_trs.html'
})

export class dt_trsPage { 

	rootPage: any;
  	items: Array<{ title: string, page: any }>;



  constructor(public navCtrl: NavController, public navParams: NavParams) { 

     this.rootPage = 'ListsPage';
    this.items = [
      {
        title: '1.Kapan Muhammad SAW Lahir?',
        page : 'trs_1Page'
      },
      {
        title: '2.Nabi Muhammad SAW dalam Kitab Veda',
        page : 'trs_2Page'
      },
      {
        title: '3.Tujuh Kisah Kesabaran dan Kedermawanan Nabi ',
        page: 'trs_3Page'
        },
      {
        title: '4.Dahsyatnya Cinta Nabi',
        page: 'trs_4Page'
      },
      {
        title: '5.Melihat Baginda Rasulullah SAW',
        page: 'trs_5Page'
      },
      {
        title: '6.Mujanat Sayyidina Ali KW',
        page: 'trs_6Page'
      },
      {
        title: '7.KEUTAMAAN BAGI ORANG YANG MEMILIKI KEUTAMAAN',
        page: 'trs_7Page'
      },
      {
        title: '8.Potret Umar Bin Khattab Ketika Membaca Al Quran',
        page: 'trs_8Page'
      },
      {
        title: '9.KETIKA UMAR MENANGIS',
        page: 'trs_9Page'
      },
      {
        title: '10.Aku Merasa Ridha Dengan Semua Ketentuan Tuhanku',
        page: 'trs_10Page'
      },
      {
        title: '11.Benarkah Nabi Menikahi Gadis Di Bawah Umur?',
        page: 'trs_11Page'
      },
      {
        title: '12.Perlombaan Antara Umar dan Abu Bakar',
        page: 'trs_12Page'
      },
      {
        title: '13.Gelar Buat Ali Bin Abi Thalib',
        page: 'trs_13Page'
      },
      {
        title: '14.Al Imam Sayyidina Jafar Ash Shadiq RA',
        page: 'trs_14Page'
      },
      {
        title: '15.Kejujuran Umar Bin Khattab',
        page: 'trs_15Page'
      },
      {
        title: '16.Cinta Kepada Nabi SAW',
        page: 'trs_16Page'
      },
      {
        title: '17.Perayaan Maulid Nabi dan Kontroversi Makna Bidah',
        page: 'trs_17Page'
      }

    ];

    }
    itemTapped(event, item) {
    this.navCtrl.push(item.page);
  }
}
