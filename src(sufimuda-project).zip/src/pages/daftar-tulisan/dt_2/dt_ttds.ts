// Angular
import { Component } from '@angular/core';

import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
    selector: 'dt_ttds',
    templateUrl: 'dt_ttds.html'
})

export class dt_ttdsPage { 

rootPage: any;
  	items: Array<{ title: string, page: any }>;



  constructor(public navCtrl: NavController, public navParams: NavParams) { 

     this.rootPage = 'ListsPage';
    this.items = [
      {
        title: '1.Syarat dan Kriteria Mursyid Menurut Prof. Dr. S.S. Kadirun Yahya MA. M.Sc',
        page : 'ttds_1Page'
      },
      {
        title: '2.Siapakah Wali Allah itu',
        page : 'ttds_2Page'
      },
      {
        title: '3.PIDATO PROF. DR. H SAIDI SYEKH KHADIRUN YAHYA MA, M.Sc',
        page: 'ttds_3Page'
      },
      {
        title: '4.Hakikat Sakit Seorang WALI ALLAH',
        page: 'ttds_4Page'
      },
      {
        title: '5.SHALAT KHUSYUK SALAH KAPRAH',
        page: 'ttds_5Page'
      },
            {
        title: '6.Pendapat Imam Al Ghazali Tentang Pentingnya Mursyid',
        page : 'ttds_6Page'
      },
      {
        title: '7.Siapa Yang Tidak Memerlukan Pembimbing (Mursyid)?',
        page : 'ttds_7Page'
      },
      {
        title: '8.Ka’bah VS Hati Wali',
        page: 'ttds_8Page'
      },
      {
        title: '9.Tarekat Qadiriyah',
        page: 'ttds_9Page'
      },
      {
        title: '10.ULAMA YANG MENYESATKAN ULAMA',
        page: 'ttds_10Page'
      },
      {
        title: '11.Murid yang Tamat Berguru',
        page : 'ttds_11Page'
      },
      {
        title: '12.Jika Gurumu Wali Quthub, Engkau Tidak Perlu Lagi Mencari Imam Mahdi',
        page : 'ttds_12Page'
      },
      {
        title: '13.Engkau Wahai Guruku…',
        page: 'ttds_13Page'
      },
      {
        title: '14.Seputar Akidah Sufi Terhadap Rasulullah',
        page: 'ttds_14Page'
      },
      {
        title: '15.NUR MUHAMMAD',
        page: 'ttds_15Page'
      },
      {
        title: '16.CINTA RABIAH AL-ADAWIYAH',
        page: 'ttds_16Page'
      },
      {
        title: '17.Tasawuf Ilmu Teknologi Al-Quran',
        page : 'ttds_17Page'
      },
      {
        title: '18.Nikmatnya Celaan',
        page : 'ttds_18Page'
      },
      {
        title: '19.Mempersedikit Doa',
        page: 'ttds_19Page'
      },
      {
        title: '20.AHLI SILSILAH THAREQAT NAQSYABANDIYAH',
        page: 'ttds_20Page'
      },
      {
        title: '21.Dialog Ibn Athaillah dengan Ibn Taymiyah',
        page: 'ttds_21Page'
      }, 
      {
        title: '22.Sesajen Untuk TUHAN',
        page: 'ttds_22Page'
      },
         {
        title: '23.KAKEK TUA DAN WALI ALLAH',
        page: 'ttds_23Page'
      }, 
      {
        title: '24.Dunia Sufi Yang Misteri (bagian 1)',
        page: 'ttds_24Page'
      },
        {
        title: '25.Dunia Sufi Yang Misteri (bagian 2)',
        page: 'ttds_25Page'
      }, 
      {
        title: '26.Tasawuf : Jalan Menuju Tuhan',
        page: 'ttds_26Page'
      },
      {
        title: '27.ZIKIR DALAM THAREQAT (Bag 1)',
        page: 'ttds_27Page'
      }, 
      {
        title: '28.ZIKIR DALAM THAREQAT (Bag 2)',
        page: 'ttds_28Page'
      },
       {
        title: '29.URAIAN RINGKAS MENGENAI ISRA DAN MIRAJ RASULULLAH DITINJAU DARI SUDUT ILMU METAFISIKA EKSAKTA',
        page: 'ttds_29Page'
      }, 
      {
        title: '30.Menemui Allah',
        page: 'ttds_30Page'
      },
         {
        title: '31.Memanggil Iblis',
        page: 'ttds_31Page'
      }, 
      {
        title: '32.Jangan Pakai Jubah Ilahi',
        page: 'ttds_32Page'
      },
          {
        title: '33.SYETAN PUN HAPAL AYAT KURSI',
        page: 'ttds_33Page'
      }, 
      {
        title: '34.SYETAN PUN HAPAL AYAT KURSI (bag. 2)',
        page: 'ttds_34Page'
      },
          {
        title: '35.ZUHUD YANG SEBENARNYA',
        page: 'ttds_35Page'
      }, 
      {
        title: '36.Surat Untuk Sahabat',
        page: 'ttds_36Page'
      },
          {
        title: '37.SURAT UNTUK ALLAH',
        page: 'ttds_37Page'
      }, 
      {
        title: '38.SURAT UNTUK RASULULLAH',
        page: 'ttds_38Page'
      },
           {
        title: '39.MURAQABAH; SINYAL DARI ALLAH',
        page: 'ttds_39Page'
      }, 
      {
        title: '40.jawaban Akidah Sufi Tentang Allah (2)',
        page: 'ttds_40Page'
      },
              {
        title: '41.Adab Seorang Murid kepada Guru (Pertama)',
        page: 'ttds_41Page'
      }, 
      {
        title: '42.Adab Seorang Murid Kepada Guru (Kedua)',
        page: 'ttds_42Page'
      },
        {
        title: '43.Rabithah MURSYID',
        page: 'ttds_43Page'
      }, 
      {
        title: '44.Akidah Sufi dituduh Menyimpang dari Al Quran dan Sunnah',
        page: 'ttds_44Page'
      },

   {
        title: '45.APA TANDA KITA DEKT DENGAN TUHAN?',
        page: 'ttds_45Page'
      }, 
      {
        title: '46.Menjumpai TUHAN di dalam Kamar-NYA',
        page: 'ttds_46Page'
      },
         {
        title: '47.Siapa Yang Menggoda Iblis',
        page: 'ttds_47Page'
      }, 
      {
        title: '48.Belajar Dari Taubat Abu Nawas',
      page: 'ttds_48Page'
      },
         {
        title: '49.Belajar Dari Kisah Taubat Abu Nawas (2)',
        page: 'ttds_49Page'
      }, 
      {
        title: '50.Gempa Sumatera, Teguran atau Bala?!',
        page: 'ttds_50Page'
      },
               {
        title: '51.FATWA SYEKH QARDHAWI TENTANG TASAWUF',
        page: 'ttds_51Page'
      }, 
      {
        title: '52.Jawaban Atas Akidah Sufi Tentang Allah',
        page: 'ttds_52Page'
      },
               {
        title: '53.BILA AKU CERITAKAN HALAL DARAHKU',
        page: 'ttds_53Page'
      }, 
      {
        title: '54.TASAWUF BUKAN BERASAL DARI ISLAM?',
        page: 'ttds_54Page'
      },
      {
        title: '55.SYIAH-SUNNI YANG PENTING JUMPA ALLAH',
        page: 'ttds_55Page'
      }, 
      {
        title: '56.7 Tanya Jawab Tentang Thariqat',
        page: 'ttds_56Page'
      },
           {
        title: '57.7 Tanya Jawab Tentang Thariqat (Lanjutan)',
        page: 'ttds_57Page'
      }, 
      {
        title: '58.DUHAI PUJAAN HATIKU',
        page: 'ttds_58Page'
      },
             {
        title: '59.MEREKA YANG MEMUSUHI DUNIA SUFI',
        page: 'ttds_59Page'
      }, 
      {
        title: '60.BUAH MANGGIS',
        page: 'ttds_60Page'
      },
      {
        title: '61.mari kita melakukan BIDAH',
        page: 'ttds_61Page'
      }, 
      {
        title: '62.MIMPI BERJUMPA RASULULLAH SAW',
        page: 'ttds_62Page'
      },
        {
        title: '63.Ber Wasilah kepada MURSYID',
        page: 'ttds_63Page'
      }, 
      {
        title: '64.Berwasilah Kepada MURSYID',
        page: 'ttds_64Page'
      },
            {
        title: '65.WALI ALLAH',
        page: 'ttds_65Page'
      }, 
      {
        title: '66.Apa Yang Salah Dengan Tarekat?',
        page: 'ttds_66Page'
      },
            {
        title: '67.Menarik Rambut Dalam Tepung',
        page: 'ttds_67Page'
      }, 
      {
        title: '68.Perbedaan Antara Ulama Fiqih dengan Ulama Tasawuf',
        page: 'ttds_68Page'
      },
            {
        title: '69.Surat Imam Al-Ghazali Kepada Muridnya',
        page: 'ttds_69Page'
      }, 
      {
        title: '70.Aku Kembali Lagi...',
        page: 'ttds_70Page'
      },
            {
        title: '71.ALLAH MAHA NYATA (AD-DZAHIR)',
        page: 'ttds_71Page'
      }, 
      {
        title: '72.Dua Ulama Khos Berpulang Hari Ini',
        page: 'ttds_72Page'
      },
            {
        title: '73.TIGA PULUH TAHUN UNTUK PENERANGAN BATIN',
        page: 'ttds_73Page'
      }, 
      {
        title: '74.SEPUTAR MELIHAT ALLAH',
        page: 'ttds_74Page'
      },
            {
        title: '75.Khilaf..',
        page: 'ttds_75Page'
      }, 
      {
        title: '76.Masa Lalu..',
        page: 'ttds_76Page'
      },
            {
        title: '77.TUHANKU TUHANMU TUHAN KITA',
        page: 'ttds_77Page'
      }, 
      {
        title: '78.Berguru Kepada MURSYID',
        page: 'ttds_78Page'
      },
            {
        title: '79.Tasawuf Membentuk Akhlak Mulia',
        page: 'ttds_79Page'
      }, 
      {
        title: '80.KESAKSIAN ULAMA FIQIH TENTANG TASAWUF',
        page: 'ttds_80Page'
      },
        {
        title: '81.Sudahkan Saya Ber "ISLAM KAFFAH"? (bag 1)',
        page: 'ttds_81Page'
      },
        {
        title: '82.Sudahkan Saya Ber "ISLAM KAFFAH"? (bag 2)',
        page: 'ttds_82Page'
      },
      {
        title: '83.Sudahkan Saya Ber "ISLAM KAFFAH"? (bag 3)',
        page: 'ttds_83Page'
      },
       {
        title: '84.Anak Muda, Dunia Ini Tidak Ada Manusia yang Keramat!',
        page: 'ttds_84Page'
      },
        {
        title: '85.TUHAN JUGA MANUSIA?',
        page: 'ttds_85Page'
      },
        {
        title: '86.BISAKAH MELIHAT ALLAH',
        page: 'ttds_86Page'
      },
        {
        title: '87.Rindu Rasul',
        page: 'ttds_87Page'
      },
        {
        title: '88.TAMAN SYURGA',
        page: 'ttds_88Page'
      },
        {
        title: '89.Mari Saling Memaafkan',
        page: 'ttds_89Page'
      },
        {
        title: '90.DEFINISI TASAUF',
        page: 'ttds_90Page'
      },
        {
        title: '91.Orang Sufi anti Syurga dan Tidak Takut Neraka?',
        page: 'ttds_91Page'
      },
        {
        title: '92.Syahadat Saridin',
        page: 'ttds_92Page'
      },
        {
        title: '93.TASAWUF TUJUAN HIDUP HAKIKI',
        page: 'ttds_93Page'
      },
        {
        title: '94.UJIAN SEORANG MURID',
        page: 'ttds_94Page'
      },
        {
        title: '95.PUISI',
        page: 'ttds_95Page'
      },
        {
        title: '96.KEMATIAN!!!',
        page: 'ttds_96Page'
      },
        {
        title: '97.keikhlasan 36 persen',
        page: 'ttds_97Page'
      },
        {
        title: '98.KONTAK ROHANI',
        page: 'ttds_98Page'
      },
        {
        title: '99.Guru mu MENGETAHUI......',
        page: 'ttds_99Page'
      },
        {
        title: '100.Cinta, Celaan dan 3 Nasehat Guru',
        page: 'ttds_100Page'
      }
      
      
      
      





    ];

    }
    itemTapped(event, item) {
    this.navCtrl.push(item.page);
  }
}
