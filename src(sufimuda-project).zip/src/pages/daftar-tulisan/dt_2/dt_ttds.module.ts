// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { dt_ttdsPage } from './dt_ttds';

@NgModule({
    declarations: [dt_ttdsPage],
    imports: [IonicPageModule.forChild(dt_ttdsPage)],
    exports: [dt_ttdsPage]
})
export class dt_ttdsPageModule { }