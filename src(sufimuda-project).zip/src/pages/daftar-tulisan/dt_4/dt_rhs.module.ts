// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { dt_rhsPage } from './dt_rhs';

@NgModule({
    declarations: [dt_rhsPage],
    imports: [IonicPageModule.forChild(dt_rhsPage)],
    exports: [dt_rhsPage]
})
export class dt_rhsPageModule { }