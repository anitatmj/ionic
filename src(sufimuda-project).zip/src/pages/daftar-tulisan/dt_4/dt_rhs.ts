// Angular
import { Component } from '@angular/core';

import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
    selector: 'dt_rhs',
    templateUrl: 'dt_rhs.html'
})

export class dt_rhsPage { 

rootPage: any;
  	items: Array<{ title: string, page: any }>;



  constructor(public navCtrl: NavController, public navParams: NavParams) { 

     this.rootPage = 'ListsPage';
    this.items = [
      {
        title: '1.Napak Tilas Maulana S.S. Kadirun Yahya MA. M.Sc',
        page : 'rhs_1Page'
      },
      {
        title: '2.Napak Tilas Maulana S.S. Kadirun Yahya MA. M.Sc (2)',
        page : 'rhs_2Page'
      },
      {
        title: '3.Napak Tilas Maulana S.S. Kadirun Yahya MA. M.Sc (Selesai)',
        page: 'rhs_3Page'
      },
      {
        title: '4.WALI SONGO (VERSI LAIN)',
        page: 'rhs_4Page'
      },
      {
        title: '5.SYEKH MUHAMMAD BABA SAMASI Q.S',
        page: 'rhs_5Page'
      },
            {
        title: '6.Syekh Bahauddin Muhammad bin Muhammad bin Muhammad Asy Syarif Al Husaini Al Hasani Al Uwaisi Al Bukhari QS (Syech Naqsyabandy)',
        page : 'rhs_6Page'
      },
      {
        title: '7.Mengenang SYEKH ABDUL WAHAB ROKAN',
        page : 'rhs_7Page'
      },
      {
        title: '8.Ibnu Al-Arabi',
        page: 'rhs_8Page'
      },
      {
        title: '9.Riwayat Syekh Yusuf Al-Maqassari',
        page: 'rhs_9Page'
      },
      {
        title: '10.Jalaluddin Rumi, Penyair Sufi Terbesar dari Persia',
        page: 'rhs_10Page'
      },
      {
        title: '11.HAMZAH FANSHURI',
        page : 'rhs_11Page'
      },
      {
        title: '12.Sufi Legendaris Dari Nanggroe Aceh',
        page : 'rhs_12Page'
      },
      {
        title: '13.Maulana Malik Israel : Penyebar Islam Tanah Jawa',
        page: 'rhs_13Page'
      }
    

    ];

    }
    itemTapped(event, item) {
    this.navCtrl.push(item.page);
  }
}
