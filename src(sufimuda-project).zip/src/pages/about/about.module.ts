// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { AboutPage } from './about';

@NgModule({
    declarations: [AboutPage],
    imports: [IonicPageModule.forChild(AboutPage)],
    exports: [AboutPage]
})
export class AboutPageModule { }