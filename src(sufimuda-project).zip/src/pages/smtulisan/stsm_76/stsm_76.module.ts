import { stsm_76Page } from './stsm_76';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_76Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_76Page),
  ],
  exports: [
   stsm_76Page
  ]
})
export class stsm_76PageModule { }
