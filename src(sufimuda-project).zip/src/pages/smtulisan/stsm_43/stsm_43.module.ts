import { stsm_43Page } from './stsm_43';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_43Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_43Page),
  ],
  exports: [
   stsm_43Page
  ]
})
export class stsm_43PageModule { }
