import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_43',
  templateUrl: 'stsm_43.html',
})

export class stsm_43Page {
  constructor(public navCtrl: NavController) {
  }

  
}
