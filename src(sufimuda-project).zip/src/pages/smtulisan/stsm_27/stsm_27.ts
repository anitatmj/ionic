import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_27',
  templateUrl: 'stsm_27.html',
})

export class stsm_27Page {
  constructor(public navCtrl: NavController) {
  }

  
}
