import { stsm_27Page } from './stsm_27';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_27Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_27Page),
  ],
  exports: [
   stsm_27Page
  ]
})
export class stsm_27PageModule { }
