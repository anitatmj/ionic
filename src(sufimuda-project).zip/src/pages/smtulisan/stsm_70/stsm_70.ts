import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_70',
  templateUrl: 'stsm_70.html',
})

export class stsm_70Page {
  constructor(public navCtrl: NavController) {
  }

  
}
