import { stsm_70Page } from './stsm_70';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_70Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_70Page),
  ],
  exports: [
   stsm_70Page
  ]
})
export class stsm_70PageModule { }
