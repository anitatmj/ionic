import { chas_3Page } from './chas_3';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_3Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_3Page),
  ],
  exports: [
   chas_3Page
  ]
})
export class chas_3PageModule { }
