import { stsm_51Page } from './stsm_51';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_51Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_51Page),
  ],
  exports: [
   stsm_51Page
  ]
})
export class stsm_51PageModule { }
