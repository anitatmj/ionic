import { stsm_68Page } from './stsm_68';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_68Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_68Page),
  ],
  exports: [
   stsm_68Page
  ]
})
export class stsm_68PageModule { }
