import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_68',
  templateUrl: 'stsm_68.html',
})

export class stsm_68Page {
  constructor(public navCtrl: NavController) {
  }

  
}
