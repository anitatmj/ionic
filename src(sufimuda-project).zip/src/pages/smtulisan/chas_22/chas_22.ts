import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_22',
  templateUrl: 'chas_22.html',
})

export class chas_22Page {
  constructor(public navCtrl: NavController) {
  }

  
}
