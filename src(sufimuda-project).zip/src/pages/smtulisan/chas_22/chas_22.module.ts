import { chas_22Page } from './chas_22';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_22Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_22Page),
  ],
  exports: [
   chas_22Page
  ]
})
export class chas_22PageModule { }
