import { rhs_5Page } from './rhs_5';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_5Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_5Page),
  ],
  exports: [
   rhs_5Page
  ]
})
export class rhs_5PageModule { }
