import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_5',
  templateUrl: 'rhs_5.html',
})

export class rhs_5Page {
  constructor(public navCtrl: NavController) {
  }

  
}
