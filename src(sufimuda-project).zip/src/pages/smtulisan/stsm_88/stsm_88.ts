import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_88',
  templateUrl: 'stsm_88.html',
})

export class stsm_88Page {
  constructor(public navCtrl: NavController) {
  }

  
}
