import { stsm_88Page } from './stsm_88';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_88Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_88Page),
  ],
  exports: [
   stsm_88Page
  ]
})
export class stsm_88PageModule { }
