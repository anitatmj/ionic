import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_57',
  templateUrl: 'stsm_57.html',
})

export class stsm_57Page {
  constructor(public navCtrl: NavController) {
  }

  
}
