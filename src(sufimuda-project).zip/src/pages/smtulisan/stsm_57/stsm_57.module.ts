import { stsm_57Page } from './stsm_57';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_57Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_57Page),
  ],
  exports: [
   stsm_57Page
  ]
})
export class stsm_57PageModule { }
