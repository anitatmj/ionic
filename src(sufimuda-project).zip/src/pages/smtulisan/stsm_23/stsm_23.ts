import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_23',
  templateUrl: 'stsm_23.html',
})

export class stsm_23Page {
  constructor(public navCtrl: NavController) {
  }

  
}
