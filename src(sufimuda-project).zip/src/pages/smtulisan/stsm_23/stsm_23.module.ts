import { stsm_23Page } from './stsm_23';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_23Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_23Page),
  ],
  exports: [
   stsm_23Page
  ]
})
export class stsm_23PageModule { }
