import { stsm_44Page } from './stsm_44';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_44Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_44Page),
  ],
  exports: [
   stsm_44Page
  ]
})
export class stsm_44PageModule { }
