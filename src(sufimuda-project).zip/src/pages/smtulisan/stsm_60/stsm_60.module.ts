import { stsm_60Page } from './stsm_60';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_60Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_60Page),
  ],
  exports: [
   stsm_60Page
  ]
})
export class stsm_60PageModule { }
