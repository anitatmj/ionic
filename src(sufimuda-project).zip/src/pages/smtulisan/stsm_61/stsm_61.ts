import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_61',
  templateUrl: 'stsm_61.html',
})

export class stsm_61Page {
  constructor(public navCtrl: NavController) {
  }

  
}
