import { stsm_61Page } from './stsm_61';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_61Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_61Page),
  ],
  exports: [
   stsm_61Page
  ]
})
export class stsm_61PageModule { }
