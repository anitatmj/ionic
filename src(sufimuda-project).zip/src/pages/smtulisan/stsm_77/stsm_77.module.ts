import { stsm_77Page } from './stsm_77';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_77Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_77Page),
  ],
  exports: [
   stsm_77Page
  ]
})
export class stsm_77PageModule { }
