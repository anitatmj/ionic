import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_77',
  templateUrl: 'stsm_77.html',
})

export class stsm_77Page {
  constructor(public navCtrl: NavController) {
  }

  
}
