import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_15',
  templateUrl: 'chas_15.html',
})

export class chas_15Page {
  constructor(public navCtrl: NavController) {
  }

  
}
