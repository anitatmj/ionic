import { chas_15Page } from './chas_15';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_15Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_15Page),
  ],
  exports: [
   chas_15Page
  ]
})
export class chas_15PageModule { }
