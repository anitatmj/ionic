import { chas_26Page } from './chas_26';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_26Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_26Page),
  ],
  exports: [
   chas_26Page
  ]
})
export class chas_26PageModule { }
