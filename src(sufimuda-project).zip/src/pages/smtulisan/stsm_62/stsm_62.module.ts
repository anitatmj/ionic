import { stsm_62Page } from './stsm_62';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_62Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_62Page),
  ],
  exports: [
   stsm_62Page
  ]
})
export class stsm_62PageModule { }
