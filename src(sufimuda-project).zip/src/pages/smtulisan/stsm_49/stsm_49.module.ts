import { stsm_49Page } from './stsm_49';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_49Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_49Page),
  ],
  exports: [
   stsm_49Page
  ]
})
export class stsm_49PageModule { }
