import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_80',
  templateUrl: 'stsm_80.html',
})

export class stsm_80Page {
  constructor(public navCtrl: NavController) {
  }

  
}
