import { stsm_80Page } from './stsm_80';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_80Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_80Page),
  ],
  exports: [
   stsm_80Page
  ]
})
export class stsm_80PageModule { }
