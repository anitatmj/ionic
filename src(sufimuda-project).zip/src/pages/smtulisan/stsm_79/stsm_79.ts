import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_79',
  templateUrl: 'stsm_79.html',
})

export class stsm_79Page {
  constructor(public navCtrl: NavController) {
  }

  
}
