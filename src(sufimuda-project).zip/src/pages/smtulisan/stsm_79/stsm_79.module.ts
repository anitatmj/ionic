import { stsm_79Page } from './stsm_79';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_79Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_79Page),
  ],
  exports: [
   stsm_79Page
  ]
})
export class stsm_79PageModule { }
