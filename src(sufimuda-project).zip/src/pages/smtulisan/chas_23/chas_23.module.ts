import { chas_23Page } from './chas_23';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_23Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_23Page),
  ],
  exports: [
   chas_23Page
  ]
})
export class chas_23PageModule { }
