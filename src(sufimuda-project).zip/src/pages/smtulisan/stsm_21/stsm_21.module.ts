import { stsm_21Page } from './stsm_21';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_21Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_21Page),
  ],
  exports: [
   stsm_21Page
  ]
})
export class stsm_21PageModule { }
