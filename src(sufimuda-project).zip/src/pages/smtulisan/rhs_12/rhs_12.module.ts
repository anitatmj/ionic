import { rhs_12Page } from './rhs_12';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_12Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_12Page),
  ],
  exports: [
   rhs_12Page
  ]
})
export class rhs_12PageModule { }
