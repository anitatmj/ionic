import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_12',
  templateUrl: 'rhs_12.html',
})

export class rhs_12Page {
  constructor(public navCtrl: NavController) {
  }

  
}
