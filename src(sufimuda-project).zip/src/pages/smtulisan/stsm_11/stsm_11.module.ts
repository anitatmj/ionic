import { stsm_11Page } from './stsm_11';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_11Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_11Page),
  ],
  exports: [
   stsm_11Page
  ]
})
export class stsm_11PageModule { }
