import { stsm_64Page } from './stsm_64';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_64Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_64Page),
  ],
  exports: [
   stsm_64Page
  ]
})
export class stsm_64PageModule { }
