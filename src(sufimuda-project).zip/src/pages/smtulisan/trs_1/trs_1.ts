import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-trs_1',
  templateUrl: 'trs_1.html',
})

export class trs_1Page {
  constructor(public navCtrl: NavController) {
  }

  
}
