import { trs_1Page } from './trs_1';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    trs_1Page,
  ],
  imports: [
    IonicPageModule.forChild(trs_1Page),
  ],
  exports: [
   trs_1Page
  ]
})
export class trs_1PageModule { }
