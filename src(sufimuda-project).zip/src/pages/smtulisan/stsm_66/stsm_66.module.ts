import { stsm_66Page } from './stsm_66';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_66Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_66Page),
  ],
  exports: [
   stsm_66Page
  ]
})
export class stsm_66PageModule { }
