import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_1',
  templateUrl: 'chas_1.html',
})

export class chas_1Page {
  constructor(public navCtrl: NavController) {
  }

  
}
