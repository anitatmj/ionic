import { chas_1Page } from './chas_1';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_1Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_1Page),
  ],
  exports: [
   chas_1Page
  ]
})
export class chas_1PageModule { }
