import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_16',
  templateUrl: 'chas_16.html',
})

export class chas_16Page {
  constructor(public navCtrl: NavController) {
  }

  
}
