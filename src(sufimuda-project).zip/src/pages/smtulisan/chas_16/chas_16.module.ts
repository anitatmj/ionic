import { chas_16Page } from './chas_16';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_16Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_16Page),
  ],
  exports: [
   chas_16Page
  ]
})
export class chas_16PageModule { }
