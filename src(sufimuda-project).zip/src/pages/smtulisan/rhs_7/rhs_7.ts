import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_7',
  templateUrl: 'rhs_7.html',
})

export class rhs_7Page {
  constructor(public navCtrl: NavController) {
  }

  
}
