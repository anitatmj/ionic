import { rhs_7Page } from './rhs_7';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_7Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_7Page),
  ],
  exports: [
   rhs_7Page
  ]
})
export class rhs_7PageModule { }
