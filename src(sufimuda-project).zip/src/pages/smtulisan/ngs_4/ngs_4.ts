import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-ngs_4',
  templateUrl: 'ngs_4.html',
})

export class ngs_4Page {
  constructor(public navCtrl: NavController) {
  }

  
}
