import { ngs_4Page } from './ngs_4';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    ngs_4Page,
  ],
  imports: [
    IonicPageModule.forChild(ngs_4Page),
  ],
  exports: [
   ngs_4Page
  ]
})
export class ngs_4PageModule { }
