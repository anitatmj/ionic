import { stsm_84Page } from './stsm_84';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_84Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_84Page),
  ],
  exports: [
   stsm_84Page
  ]
})
export class stsm_84PageModule { }
