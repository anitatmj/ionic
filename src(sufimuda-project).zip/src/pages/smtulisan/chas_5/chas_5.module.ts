import { chas_5Page } from './chas_5';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_5Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_5Page),
  ],
  exports: [
   chas_5Page
  ]
})
export class chas_5PageModule { }
