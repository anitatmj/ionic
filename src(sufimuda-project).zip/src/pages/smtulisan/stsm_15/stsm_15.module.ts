import { stsm_15Page } from './stsm_15';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_15Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_15Page),
  ],
  exports: [
   stsm_15Page
  ]
})
export class stsm_15PageModule { }
