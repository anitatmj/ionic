import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_15',
  templateUrl: 'stsm_15.html',
})

export class stsm_15Page {
  constructor(public navCtrl: NavController) {
  }

  
}
