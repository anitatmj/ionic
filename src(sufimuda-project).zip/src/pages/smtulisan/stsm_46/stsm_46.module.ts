import { stsm_46Page } from './stsm_46';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_46Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_46Page),
  ],
  exports: [
   stsm_46Page
  ]
})
export class stsm_46PageModule { }
