import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_46',
  templateUrl: 'stsm_46.html',
})

export class stsm_46Page {
  constructor(public navCtrl: NavController) {
  }

  
}
