import { stsm_12Page } from './stsm_12';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_12Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_12Page),
  ],
  exports: [
   stsm_12Page
  ]
})
export class stsm_12PageModule { }
