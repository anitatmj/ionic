import { stsm_14Page } from './stsm_14';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_14Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_14Page),
  ],
  exports: [
   stsm_14Page
  ]
})
export class stsm_14PageModule { }
