import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_14',
  templateUrl: 'stsm_14.html',
})

export class stsm_14Page {
  constructor(public navCtrl: NavController) {
  }

  
}
