import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_18',
  templateUrl: 'chas_18.html',
})

export class chas_18Page {
  constructor(public navCtrl: NavController) {
  }

  
}
