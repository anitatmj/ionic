import { chas_18Page } from './chas_18';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_18Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_18Page),
  ],
  exports: [
   chas_18Page
  ]
})
export class chas_18PageModule { }
