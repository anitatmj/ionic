import { stsm_4Page } from './stsm_4';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_4Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_4Page),
  ],
  exports: [
   stsm_4Page
  ]
})
export class stsm_4PageModule { }
