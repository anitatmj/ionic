import { rhs_6Page } from './rhs_6';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_6Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_6Page),
  ],
  exports: [
   rhs_6Page
  ]
})
export class rhs_6PageModule { }
