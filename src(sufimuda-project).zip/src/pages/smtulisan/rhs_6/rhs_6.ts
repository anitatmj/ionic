import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_6',
  templateUrl: 'rhs_6.html',
})

export class rhs_6Page {
  constructor(public navCtrl: NavController) {
  }

  
}
