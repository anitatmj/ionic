import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_1',
  templateUrl: 'rhs_1.html',
})

export class rhs_1Page {
  constructor(public navCtrl: NavController) {
  }

  
}
