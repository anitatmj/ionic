import { rhs_1Page } from './rhs_1';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_1Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_1Page),
  ],
  exports: [
   rhs_1Page
  ]
})
export class rhs_1PageModule { }
