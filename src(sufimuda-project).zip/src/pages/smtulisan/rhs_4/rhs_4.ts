import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_4',
  templateUrl: 'rhs_4.html',
})

export class rhs_4Page {
  constructor(public navCtrl: NavController) {
  }

  
}
