import { rhs_4Page } from './rhs_4';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_4Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_4Page),
  ],
  exports: [
   rhs_4Page
  ]
})
export class rhs_4PageModule { }
