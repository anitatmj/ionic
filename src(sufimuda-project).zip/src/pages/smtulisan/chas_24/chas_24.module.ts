import { chas_24Page } from './chas_24';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_24Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_24Page),
  ],
  exports: [
   chas_24Page
  ]
})
export class chas_24PageModule { }
