import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_24',
  templateUrl: 'chas_24.html',
})

export class chas_24Page {
  constructor(public navCtrl: NavController) {
  }

  
}
