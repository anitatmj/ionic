import { stsm_1Page } from './stsm_1';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_1Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_1Page),
  ],
  exports: [
   stsm_1Page
  ]
})
export class stsm_1PageModule { }
