import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_17',
  templateUrl: 'stsm_17.html',
})

export class stsm_17Page {
  constructor(public navCtrl: NavController) {
  }

  
}
