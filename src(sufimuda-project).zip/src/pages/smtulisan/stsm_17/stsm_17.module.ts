import { stsm_17Page } from './stsm_17';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_17Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_17Page),
  ],
  exports: [
   stsm_17Page
  ]
})
export class stsm_17PageModule { }
