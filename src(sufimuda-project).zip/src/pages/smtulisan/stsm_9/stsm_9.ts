import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_9',
  templateUrl: 'stsm_9.html',
})

export class stsm_9Page {
  constructor(public navCtrl: NavController) {
  }

  
}
