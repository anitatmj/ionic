import { stsm_9Page } from './stsm_9';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_9Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_9Page),
  ],
  exports: [
   stsm_9Page
  ]
})
export class stsm_9PageModule { }
