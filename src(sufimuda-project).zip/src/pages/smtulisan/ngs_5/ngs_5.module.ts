import { ngs_5Page } from './ngs_5';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    ngs_5Page,
  ],
  imports: [
    IonicPageModule.forChild(ngs_5Page),
  ],
  exports: [
   ngs_5Page
  ]
})
export class ngs_5PageModule { }
