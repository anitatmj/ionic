import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-ngs_5',
  templateUrl: 'ngs_5.html',
})

export class ngs_5Page {
  constructor(public navCtrl: NavController) {
  }

  
}
