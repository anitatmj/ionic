import { stsm_85Page } from './stsm_85';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_85Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_85Page),
  ],
  exports: [
   stsm_85Page
  ]
})
export class stsm_85PageModule { }
