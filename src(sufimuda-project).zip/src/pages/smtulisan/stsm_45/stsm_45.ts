import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_45',
  templateUrl: 'stsm_45.html',
})

export class stsm_45Page {
  constructor(public navCtrl: NavController) {
  }

  
}
