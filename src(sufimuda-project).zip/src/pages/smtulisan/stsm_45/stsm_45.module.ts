import { stsm_45Page } from './stsm_45';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_45Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_45Page),
  ],
  exports: [
   stsm_45Page
  ]
})
export class stsm_45PageModule { }
