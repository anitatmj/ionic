import { stsm_13Page } from './stsm_13';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_13Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_13Page),
  ],
  exports: [
   stsm_13Page
  ]
})
export class stsm_13PageModule { }
