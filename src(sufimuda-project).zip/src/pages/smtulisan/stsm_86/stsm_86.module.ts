import { stsm_86Page } from './stsm_86';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_86Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_86Page),
  ],
  exports: [
   stsm_86Page
  ]
})
export class stsm_86PageModule { }
