import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_12',
  templateUrl: 'chas_12.html',
})

export class chas_12Page {
  constructor(public navCtrl: NavController) {
  }

  
}
