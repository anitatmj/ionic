import { chas_12Page } from './chas_12';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_12Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_12Page),
  ],
  exports: [
   chas_12Page
  ]
})
export class chas_12PageModule { }
