import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_29',
  templateUrl: 'stsm_29.html',
})

export class stsm_29Page {
  constructor(public navCtrl: NavController) {
  }

  
}
