import { stsm_29Page } from './stsm_29';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_29Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_29Page),
  ],
  exports: [
   stsm_29Page
  ]
})
export class stsm_29PageModule { }
