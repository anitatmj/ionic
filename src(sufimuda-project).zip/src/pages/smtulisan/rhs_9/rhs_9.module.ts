import { rhs_9Page } from './rhs_9';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_9Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_9Page),
  ],
  exports: [
   rhs_9Page
  ]
})
export class rhs_9PageModule { }
