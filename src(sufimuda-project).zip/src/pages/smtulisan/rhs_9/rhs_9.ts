import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_9',
  templateUrl: 'rhs_9.html',
})

export class rhs_9Page {
  constructor(public navCtrl: NavController) {
  }

  
}
