import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_55',
  templateUrl: 'stsm_55.html',
})

export class stsm_55Page {
  constructor(public navCtrl: NavController) {
  }

  
}
