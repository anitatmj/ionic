import { stsm_55Page } from './stsm_55';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_55Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_55Page),
  ],
  exports: [
   stsm_55Page
  ]
})
export class stsm_55PageModule { }
