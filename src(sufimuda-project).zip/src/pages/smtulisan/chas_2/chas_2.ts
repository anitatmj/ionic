import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_2',
  templateUrl: 'chas_2.html',
})

export class chas_2Page {
  constructor(public navCtrl: NavController) {
  }

  
}
