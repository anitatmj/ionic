import { chas_2Page } from './chas_2';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_2Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_2Page),
  ],
  exports: [
   chas_2Page
  ]
})
export class chas_2PageModule { }
