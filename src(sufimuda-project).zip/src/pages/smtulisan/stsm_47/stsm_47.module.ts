import { stsm_47Page } from './stsm_47';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_47Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_47Page),
  ],
  exports: [
   stsm_47Page
  ]
})
export class stsm_47PageModule { }
