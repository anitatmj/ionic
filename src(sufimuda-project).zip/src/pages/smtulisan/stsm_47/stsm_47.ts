import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_47',
  templateUrl: 'stsm_47.html',
})

export class stsm_47Page {
  constructor(public navCtrl: NavController) {
  }

  
}
