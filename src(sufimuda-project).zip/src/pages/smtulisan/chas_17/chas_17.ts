import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_17',
  templateUrl: 'chas_17.html',
})

export class chas_17Page {
  constructor(public navCtrl: NavController) {
  }

  
}
