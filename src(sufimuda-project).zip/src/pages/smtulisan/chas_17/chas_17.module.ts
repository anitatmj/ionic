import { chas_17Page } from './chas_17';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_17Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_17Page),
  ],
  exports: [
   chas_17Page
  ]
})
export class chas_17PageModule { }
