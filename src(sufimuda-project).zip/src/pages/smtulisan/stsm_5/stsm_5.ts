import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_5',
  templateUrl: 'stsm_5.html',
})

export class stsm_5Page {
  constructor(public navCtrl: NavController) {
  }

  
}
