import { stsm_5Page } from './stsm_5';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_5Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_5Page),
  ],
  exports: [
   stsm_5Page
  ]
})
export class stsm_5PageModule { }
