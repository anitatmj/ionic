import { stsm_28Page } from './stsm_28';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_28Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_28Page),
  ],
  exports: [
   stsm_28Page
  ]
})
export class stsm_28PageModule { }
