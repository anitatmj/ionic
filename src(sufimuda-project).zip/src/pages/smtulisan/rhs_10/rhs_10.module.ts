import { rhs_10Page } from './rhs_10';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_10Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_10Page),
  ],
  exports: [
   rhs_10Page
  ]
})
export class rhs_10PageModule { }
