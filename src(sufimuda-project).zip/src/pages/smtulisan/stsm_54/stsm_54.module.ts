import { stsm_54Page } from './stsm_54';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_54Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_54Page),
  ],
  exports: [
   stsm_54Page
  ]
})
export class stsm_54PageModule { }
