import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_54',
  templateUrl: 'stsm_54.html',
})

export class stsm_54Page {
  constructor(public navCtrl: NavController) {
  }

  
}
