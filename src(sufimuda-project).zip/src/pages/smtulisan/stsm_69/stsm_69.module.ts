import { stsm_69Page } from './stsm_69';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_69Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_69Page),
  ],
  exports: [
   stsm_69Page
  ]
})
export class stsm_69PageModule { }
