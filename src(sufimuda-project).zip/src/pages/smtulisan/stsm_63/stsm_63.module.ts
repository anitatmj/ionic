import { stsm_63Page } from './stsm_63';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_63Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_63Page),
  ],
  exports: [
   stsm_63Page
  ]
})
export class stsm_63PageModule { }
