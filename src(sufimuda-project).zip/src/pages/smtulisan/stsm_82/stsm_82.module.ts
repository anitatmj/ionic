import { stsm_82Page } from './stsm_82';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_82Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_82Page),
  ],
  exports: [
   stsm_82Page
  ]
})
export class stsm_82PageModule { }
