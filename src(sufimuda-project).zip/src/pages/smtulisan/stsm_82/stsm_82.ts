import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_82',
  templateUrl: 'stsm_82.html',
})

export class stsm_82Page {
  constructor(public navCtrl: NavController) {
  }

  
}
