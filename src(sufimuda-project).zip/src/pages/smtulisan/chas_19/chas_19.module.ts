import { chas_19Page } from './chas_19';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_19Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_19Page),
  ],
  exports: [
   chas_19Page
  ]
})
export class chas_19PageModule { }
