import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_19',
  templateUrl: 'chas_19.html',
})

export class chas_19Page {
  constructor(public navCtrl: NavController) {
  }

  
}
