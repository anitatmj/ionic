import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-trs_10',
  templateUrl: 'trs_10.html',
})

export class trs_10Page {
  constructor(public navCtrl: NavController) {
  }

  
}
