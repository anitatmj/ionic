import { trs_10Page } from './trs_10';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    trs_10Page,
  ],
  imports: [
    IonicPageModule.forChild(trs_10Page),
  ],
  exports: [
   trs_10Page
  ]
})
export class trs_10PageModule { }
