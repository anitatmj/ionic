import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_13',
  templateUrl: 'rhs_13.html',
})

export class rhs_13Page {
  constructor(public navCtrl: NavController) {
  }

  
}
