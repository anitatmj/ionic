import { rhs_13Page } from './rhs_13';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_13Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_13Page),
  ],
  exports: [
   rhs_13Page
  ]
})
export class rhs_13PageModule { }
