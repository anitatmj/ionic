import { rhs_2Page } from './rhs_2';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_2Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_2Page),
  ],
  exports: [
   rhs_2Page
  ]
})
export class rhs_2PageModule { }
