import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_2',
  templateUrl: 'rhs_2.html',
})

export class rhs_2Page {
  constructor(public navCtrl: NavController) {
  }

  
}
