import { stsm_59Page } from './stsm_59';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_59Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_59Page),
  ],
  exports: [
   stsm_59Page
  ]
})
export class stsm_59PageModule { }
