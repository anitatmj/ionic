import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_59',
  templateUrl: 'stsm_59.html',
})

export class stsm_59Page {
  constructor(public navCtrl: NavController) {
  }

  
}
