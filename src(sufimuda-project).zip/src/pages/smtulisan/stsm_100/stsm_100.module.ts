import { stsm_90Page } from './stsm_90';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_90Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_90Page),
  ],
  exports: [
   stsm_90Page
  ]
})
export class stsm_90PageModule { }
