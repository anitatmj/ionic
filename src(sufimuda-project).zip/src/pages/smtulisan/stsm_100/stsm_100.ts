import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_90',
  templateUrl: 'stsm_90.html',
})

export class stsm_90Page {
  constructor(public navCtrl: NavController) {
  }

  
}
