import { stsm_50Page } from './stsm_50';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_50Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_50Page),
  ],
  exports: [
   stsm_50Page
  ]
})
export class stsm_50PageModule { }
