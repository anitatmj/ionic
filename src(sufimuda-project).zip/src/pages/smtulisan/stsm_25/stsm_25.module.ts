import { stsm_25Page } from './stsm_25';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_25Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_25Page),
  ],
  exports: [
   stsm_25Page
  ]
})
export class stsm_25PageModule { }
