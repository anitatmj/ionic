import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_25',
  templateUrl: 'stsm_25.html',
})

export class stsm_25Page {
  constructor(public navCtrl: NavController) {
  }

  
}
