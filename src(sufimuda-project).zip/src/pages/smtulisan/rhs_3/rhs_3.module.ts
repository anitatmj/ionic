import { rhs_3Page } from './rhs_3';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_3Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_3Page),
  ],
  exports: [
   rhs_3Page
  ]
})
export class rhs_3PageModule { }
