import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_3',
  templateUrl: 'rhs_3.html',
})

export class rhs_3Page {
  constructor(public navCtrl: NavController) {
  }

  
}
