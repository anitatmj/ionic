import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-ngs_1',
  templateUrl: 'ngs_1.html',
})

export class ngs_1Page {
  constructor(public navCtrl: NavController) {
  }

  
}
