import { ngs_1Page } from './ngs_1';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    ngs_1Page,
  ],
  imports: [
    IonicPageModule.forChild(ngs_1Page),
  ],
  exports: [
   ngs_1Page
  ]
})
export class ngs_1PageModule { }
