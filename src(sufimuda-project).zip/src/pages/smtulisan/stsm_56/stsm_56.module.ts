import { stsm_58Page } from './stsm_58';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_58Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_58Page),
  ],
  exports: [
   stsm_58Page
  ]
})
export class stsm_58PageModule { }
