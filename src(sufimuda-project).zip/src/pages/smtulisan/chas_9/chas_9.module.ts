import { chas_9Page } from './chas_9';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_9Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_9Page),
  ],
  exports: [
   chas_9Page
  ]
})
export class chas_9PageModule { }
