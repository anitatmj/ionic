import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_9',
  templateUrl: 'chas_9.html',
})

export class chas_9Page {
  constructor(public navCtrl: NavController) {
  }

  
}
