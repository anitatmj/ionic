import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_83',
  templateUrl: 'stsm_83.html',
})

export class stsm_83Page {
  constructor(public navCtrl: NavController) {
  }

  
}
