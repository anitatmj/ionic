import { stsm_83Page } from './stsm_83';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_83Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_83Page),
  ],
  exports: [
   stsm_83Page
  ]
})
export class stsm_83PageModule { }
