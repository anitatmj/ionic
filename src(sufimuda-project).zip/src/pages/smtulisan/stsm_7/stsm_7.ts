import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_7',
  templateUrl: 'stsm_7.html',
})

export class stsm_7Page {
  constructor(public navCtrl: NavController) {
  }

  
}
