import { stsm_7Page } from './stsm_7';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_7Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_7Page),
  ],
  exports: [
   stsm_7Page
  ]
})
export class stsm_7PageModule { }
