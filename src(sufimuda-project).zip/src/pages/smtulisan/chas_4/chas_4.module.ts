import { chas_4Page } from './chas_4';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_4Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_4Page),
  ],
  exports: [
   chas_4Page
  ]
})
export class chas_4PageModule { }
