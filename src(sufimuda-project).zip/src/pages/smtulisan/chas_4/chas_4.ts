import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_4',
  templateUrl: 'chas_4.html',
})

export class chas_4Page {
  constructor(public navCtrl: NavController) {
  }

  
}
