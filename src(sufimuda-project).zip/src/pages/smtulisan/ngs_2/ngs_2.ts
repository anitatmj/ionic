import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-ngs_2',
  templateUrl: 'ngs_2.html',
})

export class ngs_2Page {
  constructor(public navCtrl: NavController) {
  }

  
}
