import { ngs_2Page } from './ngs_2';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    ngs_2Page,
  ],
  imports: [
    IonicPageModule.forChild(ngs_2Page),
  ],
  exports: [
   ngs_2Page
  ]
})
export class ngs_2PageModule { }
