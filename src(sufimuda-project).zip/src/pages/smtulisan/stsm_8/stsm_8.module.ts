import { stsm_8Page } from './stsm_8';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_8Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_8Page),
  ],
  exports: [
   stsm_8Page
  ]
})
export class stsm_8PageModule { }
