import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_8',
  templateUrl: 'stsm_8.html',
})

export class stsm_8Page {
  constructor(public navCtrl: NavController) {
  }

  
}
