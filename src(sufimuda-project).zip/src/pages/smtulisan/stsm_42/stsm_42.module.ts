import { stsm_42Page } from './stsm_42';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_42Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_42Page),
  ],
  exports: [
   stsm_42Page
  ]
})
export class stsm_42PageModule { }
