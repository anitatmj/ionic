import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_89',
  templateUrl: 'stsm_89.html',
})

export class stsm_89Page {
  constructor(public navCtrl: NavController) {
  }

  
}
