import { stsm_89Page } from './stsm_89';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_89Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_89Page),
  ],
  exports: [
   stsm_89Page
  ]
})
export class stsm_89PageModule { }
