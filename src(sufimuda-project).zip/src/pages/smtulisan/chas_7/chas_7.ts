import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_7',
  templateUrl: 'chas_7.html',
})

export class chas_7Page {
  constructor(public navCtrl: NavController) {
  }

  
}
