import { chas_7Page } from './chas_7';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_7Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_7Page),
  ],
  exports: [
   chas_7Page
  ]
})
export class chas_7PageModule { }
