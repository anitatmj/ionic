import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_13',
  templateUrl: 'chas_13.html',
})

export class chas_13Page {
  constructor(public navCtrl: NavController) {
  }

  
}
