import { chas_13Page } from './chas_13';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_13Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_13Page),
  ],
  exports: [
   chas_13Page
  ]
})
export class chas_13PageModule { }
