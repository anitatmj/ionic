import { stsm_16Page } from './stsm_16';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_16Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_16Page),
  ],
  exports: [
   stsm_16Page
  ]
})
export class stsm_16PageModule { }
