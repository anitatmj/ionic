import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_16',
  templateUrl: 'stsm_16.html',
})

export class stsm_16Page {
  constructor(public navCtrl: NavController) {
  }

  
}
