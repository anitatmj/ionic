import { chas_25Page } from './chas_25';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_25Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_25Page),
  ],
  exports: [
   chas_25Page
  ]
})
export class chas_25PageModule { }
