import { stsm_41Page } from './stsm_41';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_41Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_41Page),
  ],
  exports: [
   stsm_41Page
  ]
})
export class stsm_41PageModule { }
