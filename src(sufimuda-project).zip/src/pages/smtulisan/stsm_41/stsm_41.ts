import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_41',
  templateUrl: 'stsm_41.html',
})

export class stsm_41Page {
  constructor(public navCtrl: NavController) {
  }

  
}
