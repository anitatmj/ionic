import { stsm_81Page } from './stsm_81';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_81Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_81Page),
  ],
  exports: [
   stsm_81Page
  ]
})
export class stsm_81PageModule { }
