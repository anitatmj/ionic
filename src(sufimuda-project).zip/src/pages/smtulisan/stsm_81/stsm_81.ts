import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_81',
  templateUrl: 'stsm_81.html',
})

export class stsm_81Page {
  constructor(public navCtrl: NavController) {
  }

  
}
