import { stsm_6Page } from './stsm_6';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_6Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_6Page),
  ],
  exports: [
   stsm_6Page
  ]
})
export class stsm_6PageModule { }
