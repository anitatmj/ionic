import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_6',
  templateUrl: 'stsm_6.html',
})

export class stsm_6Page {
  constructor(public navCtrl: NavController) {
  }

  
}
