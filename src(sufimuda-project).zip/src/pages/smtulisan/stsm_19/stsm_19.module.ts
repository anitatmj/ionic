import { stsm_19Page } from './stsm_19';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_19Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_19Page),
  ],
  exports: [
   stsm_19Page
  ]
})
export class stsm_19PageModule { }
