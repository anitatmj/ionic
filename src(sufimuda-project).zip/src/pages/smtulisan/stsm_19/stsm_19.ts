import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_19',
  templateUrl: 'stsm_19.html',
})

export class stsm_19Page {
  constructor(public navCtrl: NavController) {
  }

  
}
