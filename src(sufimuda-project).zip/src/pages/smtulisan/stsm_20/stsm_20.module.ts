import { stsm_20Page } from './stsm_20';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_20Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_20Page),
  ],
  exports: [
   stsm_20Page
  ]
})
export class stsm_20PageModule { }
