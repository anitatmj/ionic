import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_11',
  templateUrl: 'rhs_11.html',
})

export class rhs_11Page {
  constructor(public navCtrl: NavController) {
  }

  
}
