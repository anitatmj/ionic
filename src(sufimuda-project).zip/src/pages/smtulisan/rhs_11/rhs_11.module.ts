import { rhs_11Page } from './rhs_11';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_11Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_11Page),
  ],
  exports: [
   rhs_11Page
  ]
})
export class rhs_11PageModule { }
