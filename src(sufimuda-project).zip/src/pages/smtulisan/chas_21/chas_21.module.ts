import { chas_21Page } from './chas_21';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_21Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_21Page),
  ],
  exports: [
   chas_21Page
  ]
})
export class chas_21PageModule { }
