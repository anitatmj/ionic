import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_21',
  templateUrl: 'chas_21.html',
})

export class chas_21Page {
  constructor(public navCtrl: NavController) {
  }

  
}
