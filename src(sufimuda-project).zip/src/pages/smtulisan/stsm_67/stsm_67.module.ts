import { stsm_67Page } from './stsm_67';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_67Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_67Page),
  ],
  exports: [
   stsm_67Page
  ]
})
export class stsm_67PageModule { }
