import { chas_8Page } from './chas_8';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_8Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_8Page),
  ],
  exports: [
   chas_8Page
  ]
})
export class chas_8PageModule { }
