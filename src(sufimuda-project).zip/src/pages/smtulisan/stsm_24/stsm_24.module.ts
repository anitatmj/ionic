import { stsm_24Page } from './stsm_24';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_24Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_24Page),
  ],
  exports: [
   stsm_24Page
  ]
})
export class stsm_24PageModule { }
