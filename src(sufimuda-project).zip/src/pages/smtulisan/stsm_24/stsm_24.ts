import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_24',
  templateUrl: 'stsm_24.html',
})

export class stsm_24Page {
  constructor(public navCtrl: NavController) {
  }

  
}
