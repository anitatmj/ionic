import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_14',
  templateUrl: 'chas_14.html',
})

export class chas_14Page {
  constructor(public navCtrl: NavController) {
  }

  
}
