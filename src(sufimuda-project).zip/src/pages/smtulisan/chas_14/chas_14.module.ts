import { chas_14Page } from './chas_14';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_14Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_14Page),
  ],
  exports: [
   chas_14Page
  ]
})
export class chas_14PageModule { }
