import { stsm_18Page } from './stsm_18';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_18Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_18Page),
  ],
  exports: [
   stsm_18Page
  ]
})
export class stsm_18PageModule { }
