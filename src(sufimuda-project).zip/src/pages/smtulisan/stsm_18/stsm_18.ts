import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_18',
  templateUrl: 'stsm_18.html',
})

export class stsm_18Page {
  constructor(public navCtrl: NavController) {
  }

  
}
