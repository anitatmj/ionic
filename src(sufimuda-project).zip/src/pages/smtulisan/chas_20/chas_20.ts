import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_20',
  templateUrl: 'chas_20.html',
})

export class chas_20Page {
  constructor(public navCtrl: NavController) {
  }

  
}
