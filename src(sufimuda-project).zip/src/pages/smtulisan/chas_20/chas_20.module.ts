import { chas_20Page } from './chas_20';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_20Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_20Page),
  ],
  exports: [
   chas_20Page
  ]
})
export class chas_20PageModule { }
