import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_78',
  templateUrl: 'stsm_78.html',
})

export class stsm_78Page {
  constructor(public navCtrl: NavController) {
  }

  
}
