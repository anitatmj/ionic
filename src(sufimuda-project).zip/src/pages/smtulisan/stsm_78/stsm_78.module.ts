import { stsm_78Page } from './stsm_78';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_78Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_78Page),
  ],
  exports: [
   stsm_78Page
  ]
})
export class stsm_78PageModule { }
