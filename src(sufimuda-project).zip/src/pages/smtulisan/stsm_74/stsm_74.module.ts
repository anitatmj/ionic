import { stsm_74Page } from './stsm_74';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_74Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_74Page),
  ],
  exports: [
   stsm_74Page
  ]
})
export class stsm_74PageModule { }
