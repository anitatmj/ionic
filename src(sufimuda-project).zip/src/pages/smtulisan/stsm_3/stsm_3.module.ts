import { stsm_3Page } from './stsm_3';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_3Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_3Page),
  ],
  exports: [
   stsm_3Page
  ]
})
export class stsm_3PageModule { }
