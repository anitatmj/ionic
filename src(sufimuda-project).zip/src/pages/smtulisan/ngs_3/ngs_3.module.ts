import { ngs_3Page } from './ngs_3';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    ngs_3Page,
  ],
  imports: [
    IonicPageModule.forChild(ngs_3Page),
  ],
  exports: [
   ngs_3Page
  ]
})
export class ngs_3PageModule { }
