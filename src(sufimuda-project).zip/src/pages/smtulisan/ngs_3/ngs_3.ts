import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-ngs_3',
  templateUrl: 'ngs_3.html',
})

export class ngs_3Page {
  constructor(public navCtrl: NavController) {
  }

  
}
