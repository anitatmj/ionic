import { stsm_26Page } from './stsm_26';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_26Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_26Page),
  ],
  exports: [
   stsm_26Page
  ]
})
export class stsm_26PageModule { }
