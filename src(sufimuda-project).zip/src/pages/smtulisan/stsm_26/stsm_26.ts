import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_26',
  templateUrl: 'stsm_26.html',
})

export class stsm_26Page {
  constructor(public navCtrl: NavController) {
  }

  
}
