import { stsm_65Page } from './stsm_65';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_65Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_65Page),
  ],
  exports: [
   stsm_65Page
  ]
})
export class stsm_65PageModule { }
