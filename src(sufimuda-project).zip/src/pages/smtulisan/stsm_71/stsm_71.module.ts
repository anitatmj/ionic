import { stsm_71Page } from './stsm_71';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_71Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_71Page),
  ],
  exports: [
   stsm_71Page
  ]
})
export class stsm_71PageModule { }
