import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_71',
  templateUrl: 'stsm_71.html',
})

export class stsm_71Page {
  constructor(public navCtrl: NavController) {
  }

  
}
