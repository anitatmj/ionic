import { stsm_53Page } from './stsm_53';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_53Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_53Page),
  ],
  exports: [
   stsm_53Page
  ]
})
export class stsm_53PageModule { }
