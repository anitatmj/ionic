import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_53',
  templateUrl: 'stsm_53.html',
})

export class stsm_53Page {
  constructor(public navCtrl: NavController) {
  }

  
}
