import { stsm_30Page } from './stsm_30';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_30Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_30Page),
  ],
  exports: [
   stsm_30Page
  ]
})
export class stsm_30PageModule { }
