import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_30',
  templateUrl: 'stsm_30.html',
})

export class stsm_30Page {
  constructor(public navCtrl: NavController) {
  }

  
}
