import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_22',
  templateUrl: 'stsm_22.html',
})

export class stsm_22Page {
  constructor(public navCtrl: NavController) {
  }

  
}
