import { stsm_22Page } from './stsm_22';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_22Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_22Page),
  ],
  exports: [
   stsm_22Page
  ]
})
export class stsm_22PageModule { }
