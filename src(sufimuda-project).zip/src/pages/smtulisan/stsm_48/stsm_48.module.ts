import { stsm_48Page } from './stsm_48';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_48Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_48Page),
  ],
  exports: [
   stsm_48Page
  ]
})
export class stsm_48PageModule { }
