import { stsm_75Page } from './stsm_75';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_75Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_75Page),
  ],
  exports: [
   stsm_75Page
  ]
})
export class stsm_75PageModule { }
