import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_75',
  templateUrl: 'stsm_75.html',
})

export class stsm_75Page {
  constructor(public navCtrl: NavController) {
  }

  
}
