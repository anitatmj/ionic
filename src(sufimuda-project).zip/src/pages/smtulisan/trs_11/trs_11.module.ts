import { trs_11Page } from './trs_11';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    trs_11Page,
  ],
  imports: [
    IonicPageModule.forChild(trs_11Page),
  ],
  exports: [
   trs_11Page
  ]
})
export class trs_11PageModule { }
