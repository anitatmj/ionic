import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-trs_11',
  templateUrl: 'trs_11.html',
})

export class trs_11Page {
  constructor(public navCtrl: NavController) {
  }

  
}
