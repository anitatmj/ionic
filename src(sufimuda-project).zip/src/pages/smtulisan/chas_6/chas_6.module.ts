import { chas_6Page } from './chas_6';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_6Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_6Page),
  ],
  exports: [
   chas_6Page
  ]
})
export class chas_6PageModule { }
