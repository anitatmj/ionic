import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_6',
  templateUrl: 'chas_6.html',
})

export class chas_6Page {
  constructor(public navCtrl: NavController) {
  }

  
}
