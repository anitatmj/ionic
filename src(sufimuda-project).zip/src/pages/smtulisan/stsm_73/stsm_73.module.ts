import { stsm_73Page } from './stsm_73';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_73Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_73Page),
  ],
  exports: [
   stsm_73Page
  ]
})
export class stsm_73PageModule { }
