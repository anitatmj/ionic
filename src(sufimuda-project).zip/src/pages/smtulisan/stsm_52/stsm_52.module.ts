import { stsm_52Page } from './stsm_52';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_52Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_52Page),
  ],
  exports: [
   stsm_52Page
  ]
})
export class stsm_52PageModule { }
