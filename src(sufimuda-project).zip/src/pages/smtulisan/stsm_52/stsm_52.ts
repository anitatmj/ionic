import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_52',
  templateUrl: 'stsm_52.html',
})

export class stsm_52Page {
  constructor(public navCtrl: NavController) {
  }

  
}
