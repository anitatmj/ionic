import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-chas_11',
  templateUrl: 'chas_11.html',
})

export class chas_11Page {
  constructor(public navCtrl: NavController) {
  }

  
}
