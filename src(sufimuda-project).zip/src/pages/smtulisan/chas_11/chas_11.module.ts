import { chas_11Page } from './chas_11';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_11Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_11Page),
  ],
  exports: [
   chas_11Page
  ]
})
export class chas_11PageModule { }
