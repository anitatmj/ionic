import { stsm_72Page } from './stsm_72';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_72Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_72Page),
  ],
  exports: [
   stsm_72Page
  ]
})
export class stsm_72PageModule { }
