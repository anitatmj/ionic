import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_72',
  templateUrl: 'stsm_72.html',
})

export class stsm_72Page {
  constructor(public navCtrl: NavController) {
  }

  
}
