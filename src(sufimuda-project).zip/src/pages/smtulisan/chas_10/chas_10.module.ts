import { chas_10Page } from './chas_10';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    chas_10Page,
  ],
  imports: [
    IonicPageModule.forChild(chas_10Page),
  ],
  exports: [
   chas_10Page
  ]
})
export class chas_10PageModule { }
