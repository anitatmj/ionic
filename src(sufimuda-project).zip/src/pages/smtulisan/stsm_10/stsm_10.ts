import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-stsm_10',
  templateUrl: 'stsm_10.html',
})

export class stsm_10Page {
  constructor(public navCtrl: NavController) {
  }

  
}
