import { stsm_10Page } from './stsm_10';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
   stsm_10Page,
  ],
  imports: [
    IonicPageModule.forChild(stsm_10Page),
  ],
  exports: [
   stsm_10Page
  ]
})
export class stsm_10PageModule { }
