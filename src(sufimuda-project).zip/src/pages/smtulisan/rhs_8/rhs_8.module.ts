import { rhs_8Page } from './rhs_8';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    rhs_8Page,
  ],
  imports: [
    IonicPageModule.forChild(rhs_8Page),
  ],
  exports: [
   rhs_8Page
  ]
})
export class rhs_8PageModule { }
