import { Component } from '@angular/core';

import { NavController, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-rhs_8',
  templateUrl: 'rhs_8.html',
})

export class rhs_8Page {
  constructor(public navCtrl: NavController) {
  }

  
}
