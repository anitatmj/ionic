// Angular
import { NgModule, ErrorHandler, Injector } from '@angular/core'; // tslint:disable-line
import { BrowserModule } from '@angular/platform-browser';

import { ContactPage } from '../pages/contact/contact';
import { AboutPage } from '../pages/about/about';
// Ionic
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';

// Ionic Native
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

// App
import { MyApp } from './app.component';

// Custom components
import { SideMenuContentComponent } from '../shared/side-menu-content/side-menu-content.component';

@NgModule({

  declarations: [MyApp, SideMenuContentComponent,ContactPage,
AboutPage],
  imports: [BrowserModule, IonicModule.forRoot(MyApp,{tabsPlacement: 'top'})],
  bootstrap: [IonicApp],
  entryComponents: [MyApp,ContactPage,
AboutPage],
  providers: [
    StatusBar, SplashScreen,
    { provide: ErrorHandler, useClass: IonicErrorHandler }
  ]
})
export class AppModule {
  // Make the injector to be available in the entire module
  // so we can use it in the custom decorator
  static injector: Injector;

  constructor(injector: Injector) {
    AppModule.injector = injector;
  }
}
